import NextAuth from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import PocketBase from "pocketbase";

export const authOptions = {
    providers: [
        GoogleProvider({
            clientId: process.env.GOOGLE_CLIENT_ID,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        }),
    ],

    callbacks: {
        async signIn({ user }) {
            const pb = new PocketBase("http://127.0.0.1:8090");

            try {
                // 1. Admin auth is REQUIRED
                await pb.admins.authWithPassword(
                    process.env.PB_ADMIN_EMAIL,
                    process.env.PB_ADMIN_PASSWORD
                );

                const email = user.email;

                // 2. Check if user already exists
                let existingUser = null;
                try {
                    existingUser = await pb
                        .collection("users")
                        .getFirstListItem(`email="${email}"`);
                } catch (err) {
                    existingUser = null;
                }

                // 3. If not exist → create
                if (!existingUser) {
                    await pb.collection("users").create({
                        email: user.email,
                        name: user.username,
                        image: user.image,
                    });
                }

                return true;
            } catch (error) {
                console.error("PocketBase error:", error);
                return false;
            }
        },
    },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };