'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { CATEGORIES, DEMO_WORKERS, TRADE_TYPES_EN, TRADE_TYPES_HI } from '@/lib/data';
import WorkersList from '@/components/WorkersList';

const STATS = [
  { icon: '👷', val: '20+', label: 'Workers Available' },
  { icon: '💼', val: '5+', label: 'Jobs Posted' },
  { icon: '⭐', val: '4.8', label: 'Average Rating' },

];

export default function HomePage() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [experienceFilter, setExperienceFilter] = useState<'experienced' | 'fresher'>('experienced');
  const [tradeFilter, setTradeFilter] = useState<string | null>(null);

  return (
    <div style={{ fontFamily: "'Outfit',sans-serif", background: '#f8fafc' }}>

      {/* ── HERO ─────────────────────────────────────────────── */}
      <section style={{ background: 'linear-gradient(135deg,#0f4c25 0%,#16a34a 55%,#22c55e 100%)', position: 'relative', overflow: 'hidden' }}>
        {/* Decorative circles */}
        <div style={{ position: 'absolute', top: -80, right: -80, width: 400, height: 400, background: 'rgba(255,255,255,0.05)', borderRadius: '50%', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: -120, left: -60, width: 300, height: 300, background: 'rgba(255,255,255,0.05)', borderRadius: '50%', pointerEvents: 'none' }} />

        <div style={{ maxWidth: 1400, margin: '0 auto', padding: '60px 24px 70px', position: 'relative' }}>
          <div style={{ maxWidth: 700 }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(255,255,255,0.15)', borderRadius: 99, padding: '6px 16px', marginBottom: 16 }}>
              <span className="live-dot" style={{ width: 8, height: 8, background: '#4ade80', borderRadius: '50%', display: 'inline-block' }} />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#fff', letterSpacing: '0.06em' }}>LIVE </span>
            </div>
            <h1 style={{ fontSize: 'clamp(36px,5vw,64px)', fontWeight: 900, color: '#fff', lineHeight: 1.1, marginBottom: 12 }}>
              Hire Workers.<br />Find Jobs.<br />
              <span style={{ color: '#4ade80' }}>Instantly.</span>
            </h1>
            <p style={{ color: 'rgba(255,255,255,0.82)', fontSize: 18, lineHeight: 1.7, marginBottom: 32, maxWidth: 520 }}>
              Plumbers, Cleaners, Cooks, Drivers & more — verified workers, real jobs, direct contact. No middleman.
            </p>

            {/* CTA Buttons */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14 }}>
              <Link href={user ? '/gigs' : '/login'}
                style={{ background: '#fff', color: '#16a34a', fontWeight: 800, fontSize: 17, padding: '16px 36px', borderRadius: 14, textDecoration: 'none', boxShadow: '0 8px 32px rgba(0,0,0,0.2)', display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                💼 Find Jobs
              </Link>
              <Link href={user ? '/gigs' : '/login'}
                style={{ background: 'rgba(255,255,255,0.18)', color: '#fff', fontWeight: 700, fontSize: 17, padding: '16px 36px', borderRadius: 14, textDecoration: 'none', border: '2px solid rgba(255,255,255,0.4)', backdropFilter: 'blur(8px)', display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                📋 Hire Someone
              </Link>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div style={{ background: 'rgba(0,0,0,0.25)', backdropFilter: 'blur(8px)', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto', padding: '0 24px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(100px,1fr))' }}>
            {STATS.map(s => (
              <div key={s.label} style={{ padding: '12px 8px', textAlign: 'center', borderRight: '1px solid rgba(255,255,255,0.08)' }}>
                <div style={{ fontSize: 'clamp(18px,4vw,22px)', marginBottom: 2 }}>{s.icon}</div>
                <div style={{ fontWeight: 900, color: '#fff', fontSize: 'clamp(16px,3vw,22px)' }}>{s.val}</div>
                <div style={{ fontSize: 'clamp(10px,2vw,12px)', color: 'rgba(255,255,255,0.65)', fontWeight: 600 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ─────────────────────────────────────── */}
      <section style={{ background: '#fff', padding: '56px 24px' }}>
        <div style={{ maxWidth: 1400, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <div style={{ fontWeight: 700, color: '#16a34a', fontSize: 13, letterSpacing: '0.1em', marginBottom: 8 }}>HOW IT WORKS</div>
            <h2 style={{ fontSize: 'clamp(24px,3vw,38px)', fontWeight: 900, color: '#0f172a' }}>Simple as 1 · 2 · 3</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))', gap: 18 }}>
            {[
              { step: '01', icon: '📱', title: 'Sign In Free', desc: 'One click with Google or GitHub. Zero fees to join.', color: '#f0fdf4', accent: '#16a34a' },
              { step: '02', icon: '🔍', title: 'Browse or Post', desc: 'Find jobs near you or post your own job in 30 seconds.', color: '#eff6ff', accent: '#3b82f6' },
              { step: '03', icon: '📞', title: 'Connect & Work', desc: 'Call directly. No commission. No middleman. Simple.', color: '#fef9ee', accent: '#f59e0b' },
            ].map(s => (
              <div key={s.step} style={{ background: s.color, borderRadius: 20, padding: '24px 20px', position: 'relative', overflow: 'hidden' }}>
                <div style={{ position: 'absolute', top: -10, right: -10, fontSize: 80, fontWeight: 900, color: s.accent, opacity: 0.07, lineHeight: 1 }}>{s.step}</div>
                <div style={{ width: 56, height: 56, background: '#fff', borderRadius: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, marginBottom: 14, boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}>{s.icon}</div>
                <div style={{ fontWeight: 900, color: '#0f172a', fontSize: 18, marginBottom: 6 }}>{s.title}</div>
                <div style={{ color: '#64748b', fontSize: 14, lineHeight: 1.7 }}>{s.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── SERVICES GRID ────────────────────────────────────── */}
      <section style={{ padding: '56px 24px', background: '#f8fafc' }}>
        <div style={{ maxWidth: 1400, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 32, flexWrap: 'wrap', gap: 12 }}>
            <div>
              <div style={{ fontWeight: 700, color: '#16a34a', fontSize: 13, letterSpacing: '0.1em', marginBottom: 6 }}>SERVICES</div>
              <h2 style={{ fontSize: 'clamp(22px,3vw,36px)', fontWeight: 900, color: '#0f172a' }}>What kind of work?</h2>
            </div>
            <Link href={user ? '/gigs' : '/login'} style={{ color: '#16a34a', fontWeight: 700, fontSize: 14, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4 }}>
              See all jobs →
            </Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(200px,1fr))', gap: 12 }}>
            {CATEGORIES.slice(0, 8).map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className="hover-lift"
                style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 18, padding: '20px 16px', textDecoration: 'none', display: 'block', boxShadow: '0 1px 4px rgba(0,0,0,0.05)', cursor: 'pointer', fontFamily: 'inherit', fontSize: 'inherit', fontWeight: 'inherit', borderStyle: 'solid', transition: 'all 0.3s ease' }}
                onMouseEnter={(e) => {
                  (e.currentTarget as any).style.boxShadow = '0 8px 20px rgba(0,0,0,0.12)';
                  (e.currentTarget as any).style.transform = 'translateY(-4px)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as any).style.boxShadow = '0 1px 4px rgba(0,0,0,0.05)';
                  (e.currentTarget as any).style.transform = 'translateY(0)';
                }}
              >
                <div style={{ width: 52, height: 52, background: '#f0fdf4', border: '1px solid #d1fae5', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, marginBottom: 8 }}>{cat.icon}</div>
                <div style={{ fontWeight: 800, color: '#0f172a', fontSize: 15, marginBottom: 3, textAlign: 'left' }}>{cat.label}</div>
                <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 6, textAlign: 'left' }}>{cat.tagline}</div>
                <div style={{ fontSize: 12, fontWeight: 700, color: '#16a34a', textAlign: 'left' }}>➜ View  workers</div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── DISCOVER WORKERS ─────────────────────────────────── */}
      <section style={{ padding: '56px 24px', background: '#fff' }}>
        <div style={{ maxWidth: 1400, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <div style={{ fontWeight: 700, color: '#16a34a', fontSize: 13, letterSpacing: '0.1em', marginBottom: 8 }}>DISCOVER WORKERS</div>
            <h2 style={{ fontSize: 'clamp(24px,3vw,38px)', fontWeight: 900, color: '#0f172a' }}>Experienced Pros & Fresh Talent</h2>
            <p style={{ color: '#64748b', fontSize: 16, maxWidth: 600, margin: '0 auto' }}>All workers are verified with ID, background checks, and skill tests. Choose based on experience level.</p>
          </div>

          {/* Experience Tabs */}
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
            <div style={{ display: 'flex', background: '#f1f5f9', borderRadius: 12, padding: 4 }}>
              <button
                onClick={() => setExperienceFilter('experienced')}
                style={{
                  padding: '10px 20px',
                  borderRadius: 8,
                  border: 'none',
                  background: experienceFilter === 'experienced' ? '#16a34a' : 'transparent',
                  color: experienceFilter === 'experienced' ? '#fff' : '#64748b',
                  fontWeight: 700,
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  fontSize: 14
                }}
              >
                🏆 Experienced (5+ yrs)
              </button>
              <button
                onClick={() => setExperienceFilter('fresher')}
                style={{
                  padding: '10px 20px',
                  borderRadius: 8,
                  border: 'none',
                  background: experienceFilter === 'fresher' ? '#16a34a' : 'transparent',
                  color: experienceFilter === 'fresher' ? '#fff' : '#64748b',
                  fontWeight: 700,
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  fontSize: 14
                }}
              >
                🌱 Freshers (under 5 yrs)
              </button>
            </div>
          </div>

          {/* Trade Filter */}
          <div style={{ marginBottom: 24 }}>
            <p style={{ fontSize: 12, fontWeight: 700, color: '#94a3b8', marginBottom: 8, letterSpacing: '0.05em' }}>FILTER BY TRADE</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(110px,1fr))', gap: 8 }}>
              {(TRADE_TYPES_EN).map((trade, idx) => (
                <button
                  key={idx}
                  onClick={() => setTradeFilter(tradeFilter === trade ? null : trade)}
                  style={{
                    padding: '8px 14px',
                    borderRadius: 10,
                    border: tradeFilter === trade ? 'none' : '1.5px solid #e2e8f0',
                    background: tradeFilter === trade ? '#16a34a' : '#fff',
                    color: tradeFilter === trade ? '#fff' : '#475569',
                    fontWeight: 600,
                    fontSize: 13,
                    cursor: 'pointer',
                    transition: 'all 0.15s',
                    boxShadow: tradeFilter === trade ? '0 2px 8px rgba(22,163,74,0.2)' : 'none'
                  }}
                >
                  {trade}
                </button>
              ))}
            </div>
          </div>

          {/* Workers Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: 16 }}>
            {DEMO_WORKERS.filter(w => w.verified && w.experience_level === experienceFilter && (!tradeFilter || (w as any).trade === tradeFilter || w.role.includes(tradeFilter))).slice(0, 6).map(worker => (
              <div key={worker.id} style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 16, padding: 16, boxShadow: '0 2px 8px rgba(0,0,0,0.06)', transition: 'all 0.3s ease' }}
                onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-4px)')}
                onMouseLeave={(e) => (e.currentTarget.style.transform = 'translateY(0)')}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                  <div style={{ width: 48, height: 48, background: '#16a34a', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 18 }}>
                    {worker.initials}
                  </div>
                  <div>
                    <div style={{ fontWeight: 800, color: '#0f172a', fontSize: 16 }}>{worker.name}</div>
                    <div style={{ color: '#64748b', fontSize: 14 }}>{worker.role}</div>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <span style={{ color: '#f59e0b' }}>⭐</span>
                    <span style={{ fontWeight: 700, color: '#0f172a' }}>{worker.rating}</span>
                  </div>
                  <span style={{ color: '#94a3b8' }}>•</span>
                  <span style={{ color: '#64748b', fontSize: 14 }}>{worker.jobs} jobs</span>
                  <span style={{ color: '#94a3b8' }}>•</span>
                  <span style={{ color: '#64748b', fontSize: 14 }}>{worker.exp}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ fontWeight: 800, color: '#16a34a', fontSize: 16 }}>{worker.price}</div>
                  <div style={{ background: '#dcfce7', color: '#166534', padding: '4px 8px', borderRadius: 6, fontSize: 12, fontWeight: 700 }}>✓ Verified</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ textAlign: 'center', marginTop: 32 }}>
            <button
              onClick={() => { setSelectedCategory('all'); setTradeFilter(null); }}
              style={{ background: '#16a34a', color: '#fff', border: 'none', padding: '12px 24px', borderRadius: 12, fontWeight: 800, fontSize: 16, cursor: 'pointer', boxShadow: '0 4px 16px rgba(22,163,74,0.3)' }}
            >
              Browse All Verified Workers →
            </button>
          </div>
        </div>
      </section>

      {/* ── PICK & DROP BANNER ───────────────────────────────── */}
      <section style={{ padding: '0 24px 56px', background: '#f8fafc' }}>
        <div style={{ maxWidth: 1400, margin: '0 auto' }}>
          <div style={{ background: 'linear-gradient(135deg,#0f172a 0%,#1e3a5f 100%)', borderRadius: 28, padding: '48px 40px', display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 24, position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: -60, right: 200, width: 200, height: 200, background: 'rgba(255,255,255,0.04)', borderRadius: '50%', pointerEvents: 'none' }} />
            <div style={{ position: 'absolute', bottom: -80, right: -40, width: 300, height: 300, background: 'rgba(22,163,74,0.08)', borderRadius: '50%', pointerEvents: 'none' }} />
            <div style={{ position: 'relative' }}>
              <div style={{ background: 'rgba(22,163,74,0.2)', color: '#4ade80', borderRadius: 99, padding: '5px 14px', fontSize: 12, fontWeight: 700, display: 'inline-block', marginBottom: 10 }}>🛵 NEW</div>
              <h3 style={{ fontSize: 28, fontWeight: 900, color: '#fff', marginBottom: 8, lineHeight: 1.2 }}>Pick & Drop Runner</h3>
              <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: 14, maxWidth: 480, lineHeight: 1.6 }}>
                Need groceries, medicine, or a parcel delivered? Send a verified runner. Track them live on map. Starting ₹39.
              </p>
            </div>
            <Link href={user ? '/pick-drop' : '/login'}
              style={{ background: '#16a34a', color: '#fff', fontWeight: 800, padding: '16px 36px', borderRadius: 16, textDecoration: 'none', fontSize: 16, display: 'inline-flex', alignItems: 'center', gap: 8, boxShadow: '0 4px 20px rgba(22,163,74,0.4)', position: 'relative', flexShrink: 0 }}>
              Book a Runner →
            </Link>
          </div>
        </div>
      </section>

      {/* ── TRUST SECTION ────────────────────────────────────── */}
      <section style={{ background: '#fff', padding: '56px 24px' }}>
        <div style={{ maxWidth: 1400, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 36 }}>
            <h2 style={{ fontSize: 'clamp(22px,3vw,36px)', fontWeight: 900, color: '#0f172a', marginBottom: 6 }}>Why UrbanServe?</h2>
            <p style={{ color: '#64748b', fontSize: 16 }}>Built for India's workers and employers</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 16 }}>
            {[
              { icon: '🔒', title: 'Verified Workers', desc: 'Every worker is ID-verified with Aadhaar and skill-tested.', color: '#f0fdf4' },
              { icon: '📞', title: 'Direct Contact', desc: 'Call or message directly. Zero commission on connections.', color: '#eff6ff' },
              { icon: '⚡', title: 'Instant Booking', desc: 'Post a job or apply in under 60 seconds. Always.', color: '#fef9ee' },
              { icon: '🌍', title: '+1 Cities', desc: 'Available across major cities and towns in India.', color: '#fdf4ff' },
            ].map(f => (
              <div key={f.title} style={{ background: f.color, borderRadius: 20, padding: '20px 16px' }}>
                <div style={{ fontSize: 32, marginBottom: 10 }}>{f.icon}</div>
                <div style={{ fontWeight: 800, color: '#0f172a', fontSize: 16, marginBottom: 6 }}>{f.title}</div>
                <div style={{ color: '#64748b', fontSize: 14, lineHeight: 1.6 }}>{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── BOTTOM CTA ───────────────────────────────────────── */}
      <section style={{ background: 'linear-gradient(135deg,#16a34a,#14532d)', padding: '60px 24px', textAlign: 'center' }}>
        <div style={{ maxWidth: 600, margin: '0 auto' }}>
          <h2 style={{ fontSize: 'clamp(26px,4vw,46px)', fontWeight: 900, color: '#fff', marginBottom: 10, lineHeight: 1.2 }}>
            Start Today. It's Free.
          </h2>
          <p style={{ color: 'rgba(255,255,255,0.75)', fontSize: 16, marginBottom: 28 }}>
            Join 12,000+ workers and employers already using UrbanServe.
          </p>
          <Link href={user ? '/gigs' : '/login'}
            style={{ background: '#fff', color: '#16a34a', fontWeight: 900, fontSize: 16, padding: '14px 40px', borderRadius: 16, textDecoration: 'none', display: 'inline-block', boxShadow: '0 8px 32px rgba(0,0,0,0.25)' }}>
            Get Started Free →
          </Link>
        </div>
      </section>

      {/* Workers List Modal */}
      {selectedCategory && (
        <WorkersList
          categoryId={selectedCategory}
          onClose={() => setSelectedCategory(null)}
        />
      )}
    </div>
  );
}









